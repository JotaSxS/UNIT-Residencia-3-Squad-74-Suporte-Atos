using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using SupportAtos.Application.Options;
using SupportAtos.Application.Abstractions;
using SupportAtos.Application.Ports;
using SupportAtos.Domain.Entities;
using SupportAtos.Domain.Enums;

namespace SupportAtos.Api.Authentication;

public static class AuthenticationSetup
{
    private const string FalhaProvisionamento = "SupportAtos.FalhaProvisionamento";
    public const string ApiKeyScheme = "ApiKey";
    public const string ApiKeyHeaderName = "X-Api-Key";
    public const string ScopeClaim = "scope";
    public const string PortalScope = "portal";
    public const string AutomacaoScope = "automacao";
    public const string PolicyPortal = "Portal";
    public const string PolicyAutomacao = "Automacao";
    public const string PolicyEquipe = "Equipe";
    public const string PolicyEquipeAdmin = "EquipeAdmin";
    public const string PolicyAtribuicao = "Atribuicao";
    public const string PolicyJwt = "Jwt";
    public const string PolicyPortalOuEquipe = "PortalOuEquipe";

    public static IServiceCollection AddSsoAuthentication(this IServiceCollection services, IConfiguration configuration)
    {
        var sso = new SsoSettings();
        configuration.GetSection("Sso").Bind(sso);
        services.Configure<SsoSettings>(configuration.GetSection("Sso"));

        if (string.IsNullOrWhiteSpace(sso.JwksUrl) && string.IsNullOrWhiteSpace(sso.PublicKeyPem))
        {
            throw new InvalidOperationException(
                "SSO não configurado: defina 'Sso:JwksUrl' (produção) ou 'Sso:PublicKeyPem' (local/testes) via user-secrets ou variáveis de ambiente.");
        }

        if (string.IsNullOrWhiteSpace(sso.Issuer))
        {
            throw new InvalidOperationException(
                "SSO não configurado: defina 'Sso:Issuer' via user-secrets ou variáveis de ambiente.");
        }

        if (string.IsNullOrWhiteSpace(sso.Audience))
        {
            throw new InvalidOperationException(
                "SSO não configurado: defina 'Sso:Audience' via user-secrets ou variáveis de ambiente.");
        }

        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(jwt =>
        {
            jwt.MapInboundClaims = false;
            jwt.SaveToken = true;

            var tvp = jwt.TokenValidationParameters;
            tvp.ClockSkew = TimeSpan.FromSeconds(sso.ClockSkewSeconds);
            tvp.ValidIssuer = sso.Issuer;
            tvp.ValidAudience = sso.Audience;
            tvp.ValidAlgorithms = new[] { SecurityAlgorithms.RsaSha256 };
            tvp.NameClaimType = sso.ClaimNames.Nome;
            tvp.RoleClaimType = sso.ClaimNames.Role;
            tvp.ValidateIssuerSigningKey = true;
            tvp.ValidateIssuer = true;
            tvp.ValidateAudience = true;
            tvp.ValidateLifetime = true;

            if (!string.IsNullOrWhiteSpace(sso.PublicKeyPem))
            {
                tvp.IssuerSigningKey = ChaveRsaDePem(sso.PublicKeyPem);
            }
            else
            {
                var retriever = new HttpDocumentRetriever { RequireHttps = true };
                jwt.ConfigurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                    sso.JwksUrl!,
                    new OpenIdConnectConfigurationRetriever(),
                    retriever)
                {
                    AutomaticRefreshInterval = TimeSpan.FromHours(12),
                    RefreshInterval = TimeSpan.FromMinutes(5)
                };

                tvp.IssuerSigningKeyResolver = (token, securityToken, kid, parameters) =>
                {
                    var configuracao = jwt.ConfigurationManager
                        .GetConfigurationAsync(CancellationToken.None).GetAwaiter().GetResult();
                    return string.IsNullOrEmpty(kid)
                        ? configuracao.SigningKeys
                        : configuracao.SigningKeys.Where(chave => chave.KeyId == kid);
                };
            }

            jwt.Events = new JwtBearerEvents
            {
                OnAuthenticationFailed = context =>
                {
                    // Falhas de infraestrutura/provisionamento não são tokens inválidos.
                    if (context.HttpContext.Items.ContainsKey(FalhaProvisionamento)
                        || context.Exception.GetBaseException() is HttpRequestException)
                    {
                        throw new InvalidOperationException("Falha ao preparar a identidade autenticada.", context.Exception);
                    }

                    // Também cobre exceções de claims lançadas em OnTokenValidated.
                    context.Fail(context.Exception);
                    return Task.CompletedTask;
                },
                OnTokenValidated = async context =>
                {
                    var tipoToken = context.Principal?.FindFirst("tipo")?.Value;

                    if (tipoToken == "interno")
                    {
                        // Token interno (login próprio com e-mail+senha): não executar
                        // UserProvisioningService. Validar no banco que o usuário
                        // ainda existe, possui credencial ativa e papel autorizado.
                        var usuarioRepository = context.HttpContext.RequestServices.GetRequiredService<IUsuarioRepository>();

                        var sub = context.Principal?.FindFirst(sso.ClaimNames.Sub)?.Value
                            ?? context.Principal?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                        var email = context.Principal?.FindFirst(sso.ClaimNames.Email)?.Value
                            ?? context.Principal?.FindFirst(ClaimTypes.Email)?.Value;
                        var nome = context.Principal?.FindFirst(sso.ClaimNames.Nome)?.Value
                            ?? context.Principal?.FindFirst(ClaimTypes.Name)?.Value;
                        var papelStr = context.Principal?.FindFirst(sso.ClaimNames.Role)?.Value
                            ?? context.Principal?.FindFirst(ClaimTypes.Role)?.Value;
                        var grupoIdStr = context.Principal?.FindFirst(sso.ClaimNames.GrupoEmpresaId)?.Value;

                        if (string.IsNullOrWhiteSpace(sub) || !int.TryParse(sub, out var usuarioIdInterno))
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: identificação do usuário ausente."));
                            return;
                        }

                        var usuario = await usuarioRepository.GetByIdAsync(usuarioIdInterno, context.HttpContext.RequestAborted);
                        if (usuario is null)
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: usuário não encontrado."));
                            return;
                        }

                        if (usuario.Credencial is null || !usuario.Credencial.Ativo)
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: credencial de acesso não encontrada ou inativa."));
                            return;
                        }

                        if (usuario.Credencial.EstaBloqueado())
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: conta bloqueada por tentativas falhas."));
                            return;
                        }

                        if (usuario.Papel is not (PapelUsuario.Admin or PapelUsuario.Supervisor or PapelUsuario.Agente))
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: papel não autorizado."));
                            return;
                        }

                        // Dados de autorização devem vir do banco, não do JWT antigo.
                        // Isso garante que rebaixamento de papel ou alteração de grupo
                        // revoguem acessos concedidos por tokens emitidos anteriormente.
                        var papelAtual = usuario.Papel;
                        var grupoAtual = usuario.GrupoEmpresaId;

                        // Substitui a claim 'role' pelo papel atual consultado no banco,
                        // garantindo que alterações de papel revoguem efetivamente acessos
                        // concedidos por tokens emitidos anteriormente.
                        if (context.Principal?.Identity is ClaimsIdentity identidadeInterna)
                        {
                            foreach (var claimCargo in identidadeInterna.FindAll(sso.ClaimNames.Role).ToList())
                            {
                                identidadeInterna.RemoveClaim(claimCargo);
                            }

                            foreach (var claim in identidadeInterna.FindAll(ClaimTypes.Role).ToList())
                                identidadeInterna.RemoveClaim(claim);
                            foreach (var claim in identidadeInterna.FindAll(sso.ClaimNames.GrupoEmpresaId).ToList())
                                identidadeInterna.RemoveClaim(claim);
                            if (grupoAtual.HasValue)
                                identidadeInterna.AddClaim(new Claim(sso.ClaimNames.GrupoEmpresaId, grupoAtual.Value.ToString()));
                            identidadeInterna.AddClaim(new Claim(sso.ClaimNames.Role, papelAtual.ToString()));
                        }

                        // Valida que o JWT antigo tem claims obrigatórias (formato),
                        // mas a autorização usa os dados do banco.
                        if (string.IsNullOrWhiteSpace(email))
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: e-mail ausente."));
                            return;
                        }

                        if (string.IsNullOrWhiteSpace(nome))
                        {
                            context.Fail(new SecurityTokenValidationException("Token interno inválido: nome ausente."));
                            return;
                        }

                        var contextoInterno = new PortalUserContext(
                            usuarioIdInterno,
                            grupoAtual,
                            sub,
                            sub,
                            email,
                            nome,
                            nome,
                            papelAtual);

                        context.HttpContext.Items[PortalUserContextItems.Chave] = contextoInterno;
                        context.HttpContext.Items[PortalUserContextItems.ExpiracaoToken] =
                            DateTime.SpecifyKind(context.SecurityToken.ValidTo, DateTimeKind.Utc);

                        return;
                    }

                    // Token do portal (SSO): executar provisionamento automático.
                    var claimsPortal = PortalIdentityClaimsReader.Ler(context.Principal!, sso.ClaimNames);
                    var provisioning = context.HttpContext.RequestServices.GetRequiredService<IUserProvisioningService>();

                    var contextoExterno = new PortalUserContext(
                        0, 0,
                        claimsPortal.CodigoExternoUsuario,
                        claimsPortal.CodigoExternoGrupo,
                        claimsPortal.Email,
                        claimsPortal.Nome,
                        claimsPortal.NomeGrupo,
                        claimsPortal.Papel);

                    SupportAtos.Application.DTOs.ProvisioningResult resultado;
                    try
                    {
                        resultado = await provisioning.ProvisionAsync(contextoExterno, context.HttpContext.RequestAborted);
                    }
                    catch
                    {
                        context.HttpContext.Items[FalhaProvisionamento] = true;
                        throw;
                    }

                    var portal = contextoExterno with
                    {
                        UsuarioIdInterno = resultado.UsuarioIdInterno,
                        GrupoEmpresaIdInterno = resultado.GrupoEmpresaIdInterno
                    };

                    if (context.Principal?.Identity is ClaimsIdentity identidade)
                    {
                        foreach (var claimCargo in identidade.FindAll(sso.ClaimNames.Role).ToList())
                        {
                            identidade.RemoveClaim(claimCargo);
                        }

                        identidade.AddClaim(new Claim(sso.ClaimNames.Role, portal.Papel.ToString()));
                    }

                    context.HttpContext.Items[PortalUserContextItems.Chave] = portal;
                    context.HttpContext.Items[PortalUserContextItems.ExpiracaoToken] =
                        DateTime.SpecifyKind(context.SecurityToken.ValidTo, DateTimeKind.Utc);
                }
            };
        })
        .AddScheme<ApiKeyAuthenticationOptions, ApiKeyAuthenticationHandler>(ApiKeyScheme, "API key (máquina a máquina)", null);

        return services;
    }

    private static SecurityKey ChaveRsaDePem(string pem)
    {
        var rsa = RSA.Create();
        rsa.ImportFromPem(pem);
        return new RsaSecurityKey(rsa);
    }
}
